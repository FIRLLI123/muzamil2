package com.example.muzamil;

import android.app.Application;

public class AppController extends Application {
}
