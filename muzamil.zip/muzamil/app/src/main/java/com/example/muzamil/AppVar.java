package com.example.muzamil;


//-------------- Konfigurasi ke server


public class AppVar {

    public static final String LOGIN_URL = "https://rekamitrayasa.com/muzamil/login.php";


    public static final String KEY_EMAIL = "nis";
    public static final String KEY_PASSWORD = "password";


    public static final String LOGIN_SUCCESS = "success";


//---------------------------------------------
}
