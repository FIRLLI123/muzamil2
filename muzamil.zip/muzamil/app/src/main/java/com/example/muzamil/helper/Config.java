package com.example.muzamil.helper;

public class Config {

    //public static String host = "154.41.240.6/reka/";
    //public static String host = "https://webandroidfirlli.000webhostapp.com/reka2/";
    public static String host = "https://rekamitrayasa.com/muzamil/";
    //public static String host = "https://www.rekamitrayasa.com/reka/";



    //public static String img = "http://192.168.100.159/reka3/img";
    public static String img = "https://rekamitrayasa.com/muzamil/img";
}

